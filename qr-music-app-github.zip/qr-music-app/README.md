# QR Music App (Hitster-like) – GitHub + Render

- Frontend: React + Vite (GitHub Pages przez Actions)
- Backend: Node/Express (Render, auto-deploy z GitHub)
- QR: Spotify / YouTube
- Spotify OAuth PKCE + Web Playback SDK (Premium)

Patrz sekcja "Deploy przez GitHub" na końcu.
